// ElectricEngineering.cpp : Defines the entry point for the console application.
//
