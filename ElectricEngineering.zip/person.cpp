#include<iostream>
#include"EE.h"
using namespace std;
int Person::count = 0;
void Date::init(int y,int m,int d)
{
	year = y;
	month = m;
	day = d;
}
void Date::print_ymd()
{
	cout<<year<<"-"<<month<<"-"<<day<<endl;
}
Person::Person(string tName,Date tBirth,Position tPos,Date tDat)
{
	name = tName;
	birthday = tBirth;
	position = tPos;
	dateOfWork = tDat;
	cout<<"Constructing..."<<endl;

	count++;	//��̬��Ա��1
}
Person::~Person()
{
	count--;
	cout<<"Destructing..."<<endl;
}
int Person::GetCount()
{
	return count;	//��̬��Ա����ֱ�ӵ��þ�̬���ݳ�Ա
}
void Person::SetSalary(float tWage,float tBonus,float tFine,float tFee)
{
	salary.wage = tWage;
	salary.bonus = tBonus;
	salary.fine = tFine;
	salary.fee = tFee;	//ע��Ҫ��"salary."
	
}
float Person::SumSalary()
{
	return salary.sum();
}
void Person::ShowMessage()
{
	cout<<"Number: "<<GetCount()<<endl;	
	cout<<"Mame: "<<name<<endl;
	cout<<"Birthday: ";
	birthday.print_ymd();
	switch(position)
	{
	case PROFESSOR:
		cout<<"Position: "<<"����"<<endl;
		break;	//������������٣�
	case TEACHER:
		cout<<"Position: "<<"��ʦ"<<endl;
		break;
	case TUTER:
		cout<<"Position: "<<"����Ա"<<endl;
		break;
	case DAZA:
		cout<<"Position: "<<"���ӵ�"<<endl;
		break;
	}
	cout<<"Date of Work: ";
	dateOfWork.print_ymd();
	cout<<"Salary: "<<SumSalary()<<endl;
	cout<<"**************************"<<endl;
}	